import networkx as nx
import matplotlib.pyplot as plt

g = nx.DiGraph()
L = [
    [1, 0, 0, 1, 0, 1, 1],
    [0, 1, 1, 1, 1, 1, 0],
    [1, 1, 1, 0, 1, 0, 1],
    [1, 0, 0, 0, 1, 0, 1],
    [1, 1, 1, 0, 0, 1, 1],
    [1, 1, 1, 1, 0, 1, 0],
    [0, 1, 1, 0, 0, 0, 1]
]

g = nx.DiGraph()
g.add_nodes_from([0, 1, 2, 3, 4, 5, 6])

for i in range(7):
    for j in range(7):
        if L[i][j] == 1:
            g.add_edge(i, j)

nx.draw(
    g, 
    with_labels=True, 
    node_size=1000, 
    node_color='red', 
    width=2, 
    edge_color='blue'
)
plt.show()
